Claudio Rota 816050
Alessandro Sorrentino 815999
Mottadelli Simone Paolo 820786